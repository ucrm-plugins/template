<?php
declare(strict_types=1);

echo "Default Page";

//var_dump($_GET);
//var_dump($_SERVER);
//var_dump($_POST);

session_start();

if(isset($_SESSION))
    var_dump($_SESSION);