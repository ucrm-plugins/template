<?php
declare(strict_types=1);
require __DIR__ . "/vendor/autoload.php";
require __DIR__ . "/bootstrap.php";

use MVQN\Common\Strings;

use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;

use Slim\Http\Request;
use Slim\Http\Response;

/**
 * Use an immediately invoked function here, to avoid global namespace pollution...
 *
 * @author Ryan Spaeth <rspaeth@mvqn.net>
 *
 */
(function() use ($app)
{
    $container = $app->getContainer();

    $app->get('/test/{name}', function (\Slim\Http\Request $request, \Slim\Http\Response $response, array $args) use ($container)
    {
        var_dump($request->getQueryParams());

        $response->write("This is a test! ".$args["name"]);

        return $response;
    });

    $app->map(["GET", "POST"], "/login", \UCRM\Routing\Controllers\AuthenticationController::class.":login");
    $app->get("/logout", \UCRM\Routing\Controllers\AuthenticationController::class.":logout");


    $app->get("/{file:.+}_{ext:jpg|png|pdf|txt|css|js}",
        function (Request $request, Response $response, array $args) use ($container)
        {
            $file = $args["file"];
            $ext = $args["ext"];

            // Match the Content-Type given the following extension...
            switch ($ext)
            {
                case "jpg":         $contentType = "image/jpg";                 break;
                case "png":         $contentType = "image/png";                 break;
                case "pdf":         $contentType = "application/pdf";           break;
                case "txt":         $contentType = "text/plain";                break;
                case "css":         $contentType = "text/css";                  break;
                case "js" :         $contentType = "text/javascript";           break;

                // TODO: Add more supported file types as needed!

                default   :         $contentType = "application/octet-stream";  break; // NEVER!
            }

            $path = realpath($container->get("rendererConfig")["assetsDirectory"]."$file.$ext");

            if(!$path)
                return $response->withStatus(404, "Asset not found!");

            // Set the response Content-Type header and write the contents of the file to the response body.
            $response = $response
                ->withHeader("Content-Type", $contentType)
                ->write(file_get_contents($path));

            // Then return the response!
            return $response;
        }
    );





    $app->run();
    die();


    // =================================================================================================================
    // ROUTING SYSTEM
    // =================================================================================================================


    // This is the default route that handles all GET requests...
    $app->get('/', function (\Slim\Http\Request $request, \Slim\Http\Response $response, array $args) use ($container)
    {
        // Get local references to the paths that could potentially contain our templates, assets and scripts...
        $templateDirectory = $container->get("rendererConfig")["templatesDirectory"];
        $assetsDirectory = $container->get("rendererConfig")["assetsDirectory"];
        $scriptsDirectory = $container->get("rendererConfig")["scriptsDirectory"];

        // Get local references to the extensions that are currently supported for templates, assets and scripts...
        $templateExtensions = $container->get("rendererConfig")["supportedTemplates"];
        $assetExtensions = $container->get("rendererConfig")["supportedAssets"];
        $scriptExtensions = $container->get("rendererConfig")["supportedScripts"];

        // Get the Query Parameters from the URI.
        $params = $request->getParams();

        // -------------------------------------------------------------------------------------------------------------
        // DEFAULT ROUTE
        // -------------------------------------------------------------------------------------------------------------

        // IF no query parameters were provided...
        if ($params === [] || !Strings::startsWith(array_keys($params)[0], "/"))
        {
            // THEN simply pass control to the index.php file and then return the results!
            include __DIR__ . "/index.php";
            //return $response;
            exit();

            // NOTE: This is where the standard requests would be handled, but it would be better to handle them in a
            // separate file to reduce clutter here.  The index.php file is the best in my opinion, as it will work
            // automatically in development environments.  It is not until the application is installed as a Plugin that
            // the server will restrict all HTTP/HTTPS requests to public.php!
        }

        // OTHERWISE, we need to route to the appropriate template or asset, given the first query parameter!

        // IF the root path was provided...
        if(array_keys($params)[0] === "/")
        {
            // THEN, simply return 'index' as the path; the file extension will be determined later.
            $path = "index";
        }
        else
        {
            // OTHERWISE, trim the leading '/' from the path.
            $path = ltrim(array_keys($params)[0], "/");
        }

        // Remove the path from the list of query parameters, so that the actual query parameters can be passed along.
        array_shift($params);

        // IF the path contains a trailing '/', THEN assume there is an index.* file residing at the path...
        if (Strings::endsWith($path, "/"))
            $path .= "index";

        // NOTE: This is section is necessary, as PHP converts the '.' in query strings to '_' and we may the extension!

        // Set a flag to determine if an extension was provided.
        $extensionProvided = false;

        // -------------------------------------------------------------------------------------------------------------
        // EXTENSION HANDLING
        // -------------------------------------------------------------------------------------------------------------

        // IF the current path contains any underscore characters...
        if (Strings::contains($path, "_"))
        {
            // THEN explode the parts of the path by the underscores and get the last part for inspection.
            $parts = explode("_", $path);
            $ext = array_pop($parts);

            // IF the last part of the path matches any supported template or asset file extensions...
            if (in_array($ext, $templateExtensions) || in_array($ext, $assetExtensions) || in_array($ext, $scriptExtensions))
            {
                // THEN implode the parts again, reinserting the underscores and then suffix a '.' and the extension!
                $path = implode("_", $parts) . ".$ext";
                $extensionProvided = true;
            }
        }

        // -------------------------------------------------------------------------------------------------------------
        // TEMPLATE HANDLING (.twig, .html, etc...)
        // -------------------------------------------------------------------------------------------------------------

        // Set a variable to store any found templates.
        $foundTemplate = "";

        // Loop through each type of supported template, as specified in the app/config/settings.php file...
        foreach ($templateExtensions as $extension)
        {
            // IF the provided path has a matching file with the given extension...
            if (file_exists($templateDirectory . $path . ($extensionProvided ? "" : ".$extension")))
            {
                // THEN set the found template and break from the loop, as this settings provide a file precedence!
                $foundTemplate = "$path" . ($extensionProvided ? "" : ".$extension");
                break;

                // NOTE: If file extension precedence is not desired, then the path MUST contain the file extension!
            }
        }

        // IF a matching template is found, THEN render and return the response!
        if ($foundTemplate !== "")
            return $this->renderer->render($response, $foundTemplate, $params);

        // -------------------------------------------------------------------------------------------------------------
        // ASSET HANDLING (.jpg, .png, .pdf, .txt, .css, .js, etc...)
        // -------------------------------------------------------------------------------------------------------------

        // Set a variable to store any found assets.
        $foundAsset = "";

        // Loop through each type of supported asset, as specified in the app/config/settings.php file...
        foreach ($assetExtensions as $extension)
        {
            // IF the provided path has a matching file with the given extension...
            if (file_exists($assetsDirectory . $path . ($extensionProvided ? "" : ".$extension")))
            {
                // THEN set the found asset and break from the loop, as this settings provide a file precedence!
                $foundAsset = "$path" . ($extensionProvided ? "" : ".$extension");
                break;

                // NOTE: If file extension precedence is not desired, then the path MUST contain the file extension!
            }
        }

        // IF a matching asset is found...
        if ($foundAsset !== "")
        {
            // THEN we need to determine the MIME type, load the file and return the response...

            // Get the file extension to help determine the MIME type to return.
            $extension = pathinfo($foundAsset, PATHINFO_EXTENSION);

            // Match the Content-Type given the following extension...
            switch ($extension)
            {
                case "jpg":         $contentType = "image/jpg";                 break;
                case "png":         $contentType = "image/png";                 break;
                case "pdf":         $contentType = "application/pdf";           break;
                case "txt":         $contentType = "text/plain";                break;
                case "css":         $contentType = "text/css";                  break;
                case "js" :         $contentType = "text/javascript";           break;

                // TODO: Add more supported file types as needed!

                default   :         $contentType = "application/octet-stream";  break; // NEVER!
            }

            // Set the response Content-Type header and write the contents of the file to the response body.
            $response = $response
                ->withHeader("Content-Type", $contentType)
                ->write(file_get_contents($assetsDirectory . $foundAsset));

            // Then return the response!
            return $response;
        }

        // -------------------------------------------------------------------------------------------------------------
        // SCRIPT HANDLING (.php, etc...)
        // -------------------------------------------------------------------------------------------------------------

        // Set a variable to store any found templates.
        $foundScript = "";

        // Loop through each type of supported template, as specified in the app/config/settings.php file...
        foreach ($scriptExtensions as $extension)
        {
            // IF the provided path has a matching file with the given extension...
            if (file_exists($scriptsDirectory . $path . ($extensionProvided ? "" : ".$extension")))
            {
                // THEN set the found template and break from the loop, as this settings provide a file precedence!
                $foundScript = "$path" . ($extensionProvided ? "" : ".$extension");
                break;

                // NOTE: If file extension precedence is not desired, then the path MUST contain the file extension!
            }
        }

        var_dump($extensionProvided);
        var_dump($foundScript);

        // IF a matching template is found, THEN render and return the response!
        if ($foundScript !== "")
        {
            /** @noinspection PhpIncludeInspection */
            // Pass control to the specified PHP file and then simply exit!
            include $scriptsDirectory.$foundScript;
            exit();
        }

        // Return an error page if no template or asset could be determined!
        return $this->renderer->render($response, "404.html");
    });



    // This is the default route that handles all POST requests...
    $app->post("/", function (\Slim\Http\Request $request, \Slim\Http\Response $response, array $args) use ($container)
    {
        // Get local references to the paths that could potentially contain our scripts...
        $scriptsDirectory = $container->get("rendererConfig")["scriptsDirectory"];

        // Get local references to the extensions that are currently supported for scripts...
        $scriptExtensions = $container->get("rendererConfig")["supportedScripts"];

        // Get the Query Parameters from the URI.
        $params = $request->getParams();

        // -------------------------------------------------------------------------------------------------------------
        // DEFAULT ROUTE
        // -------------------------------------------------------------------------------------------------------------

        // IF no query parameters were provided...
        if ($params === [] || !Strings::startsWith(array_keys($params)[0], "/"))
        {
            // THEN pass control to the index.php file and then simply exit!
            include __DIR__ . "/index.php";
            exit();

            // NOTE: This is where the standard requests would be handled, but it would be better to handle them in a
            // separate file to reduce clutter here.  The index.php file is the best in my opinion, as it will work
            // automatically in development environments.  It is not until the application is installed as a Plugin that
            // the server will restrict all HTTP/HTTPS requests to public.php!
        }

        // OTHERWISE, we need to route to the appropriate template or asset, given the first query parameter!

        // IF the root path was provided...
        if(array_keys($params)[0] === "/")
        {
            // THEN, simply return 'index' as the path; the file extension will be determined later.
            $path = "index";
        }
        else
        {
            // OTHERWISE, trim the leading '/' from the path.
            $path = ltrim(array_keys($params)[0], "/");
        }

        // Remove the path from the list of query parameters, so that the actual query parameters can be passed along.
        array_shift($params);

        // IF the path contains a trailing '/', THEN assume there is an index.* file residing at the path...
        if (Strings::endsWith($path, "/"))
            $path .= "index";

        // NOTE: This is section is necessary, as PHP converts the '.' in query strings to '_' and we may the extension!

        // Set a flag to determine if an extension was provided.
        $extensionProvided = false;

        // -------------------------------------------------------------------------------------------------------------
        // EXTENSION HANDLING
        // -------------------------------------------------------------------------------------------------------------

        // IF the current path contains any underscore characters...
        if (Strings::contains($path, "_"))
        {
            // THEN explode the parts of the path by the underscores and get the last part for inspection.
            $parts = explode("_", $path);
            $ext = array_pop($parts);

            // IF the last part of the path matches any supported template or asset file extensions...
            if (in_array($ext, $scriptExtensions))
            {
                // THEN implode the parts again, reinserting the underscores and then suffix a '.' and the extension!
                $path = implode("_", $parts) . ".$ext";
                $extensionProvided = true;
            }
        }

        // -------------------------------------------------------------------------------------------------------------
        // SCRIPT HANDLING (.php, etc...)
        // -------------------------------------------------------------------------------------------------------------

        // Set a variable to store any found templates.
        $foundScript = "";

        // Loop through each type of supported template, as specified in the app/config/settings.php file...
        foreach ($scriptExtensions as $extension)
        {
            // IF the provided path has a matching file with the given extension...
            if (file_exists($scriptsDirectory . $path . ($extensionProvided ? "" : ".$extension")))
            {
                // THEN set the found template and break from the loop, as this settings provide a file precedence!
                $foundScript = "$path" . ($extensionProvided ? "" : ".$extension");
                break;

                // NOTE: If file extension precedence is not desired, then the path MUST contain the file extension!
            }
        }

        // IF a matching template is found, THEN render and return the response!
        if ($foundScript !== "")
        {
            /** @noinspection PhpIncludeInspection */
            // Pass control to the specified PHP file and then simply exit!
            include $scriptsDirectory.$foundScript;
            exit();
        }

        // Return an error page if no template or asset could be determined!
        return $this->renderer->render($response, "404.html");

    });

    // Run the Slim Framework Application!
    $app->run();

})();

