<?php
declare(strict_types=1);

namespace MVQN\SFTP\Exceptions;

final class RemoteConnectionException extends \Exception
{
}
