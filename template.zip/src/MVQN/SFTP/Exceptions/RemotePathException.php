<?php
declare(strict_types=1);

namespace MVQN\SFTP\Exceptions;

final class RemotePathException extends \Exception
{
}
