<?php
declare(strict_types=1);

namespace MVQN\SFTP\Exceptions;

final class LocalStreamException extends \Exception
{
}
