<?php
declare(strict_types=1);

namespace UCRM\Routing\Middleware;

use MVQN\Common\Strings;

class QueryStringRouter
{
    /**
     * Example middleware invokable class
     *
     * @param  \Psr\Http\Message\ServerRequestInterface $request  PSR7 request
     * @param  \Psr\Http\Message\ResponseInterface      $response PSR7 response
     * @param  callable                                 $next     Next middleware
     *
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function __invoke($request, $response, $next)
    {
        $params = $request->getQueryParams();

        // -------------------------------------------------------------------------------------------------------------
        // PARAM CONVERSION
        // -------------------------------------------------------------------------------------------------------------

        // IF no query parameters were provided OR the root path was specified...
        if ($params === [] || !Strings::startsWith(array_keys($params)[0], "/") || array_keys($params)[0] === "/")
            $path = "/";
        else
            $path = array_keys($params)[0];

        // Remove the path from the list of query parameters, so that the actual query parameters can be passed along.
        array_shift($params);

        // IF the path contains a trailing '/', THEN assume there is an index.* file residing at the path...
        if (Strings::endsWith($path, "/"))
            $path .= "index";

        $query = [];

        foreach($params as $name => $value)
            $query[] = "$name=$value";

        $query = implode("&", $query);

        $uri = $request->getUri()
            ->withPath($path)
            ->withQuery($query);

        $request = $request
            ->withUri($uri)
            ->withQueryParams($params);

        $response = $next($request, $response);

        return $response;
    }
}