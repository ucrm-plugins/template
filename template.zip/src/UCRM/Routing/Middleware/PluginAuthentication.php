<?php
declare(strict_types=1);

namespace UCRM\Routing\Middleware;

use MVQN\Common\Strings;
use Slim\Container;

class PluginAuthentication
{

    /**
     * Example middleware invokable class
     *
     * @param  \Psr\Http\Message\ServerRequestInterface $request  PSR7 request
     * @param  \Psr\Http\Message\ResponseInterface      $response PSR7 response
     * @param  callable                                 $next     Next middleware
     *
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function __invoke($request, $response, $next)
    {
        if (session_status() == PHP_SESSION_NONE)
            session_start();

        $requestedUri = $request->getUri()->getPath();
        $requestedParams = [];

        foreach($request->getQueryParams() as $name => $value)
            $requestedParams[] = "$name=$value";

        $requestedParams = implode("&", $requestedParams);

        if($requestedUri !== "/login" && (!isset($_SESSION["authenticated"]) || !$_SESSION["authenticated"]))
        {
            header("Location: public.php?/login&requestedUrl=$requestedUri&$requestedParams");
            exit();
        }

        return $next($request, $response);
    }
}